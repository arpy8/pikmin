# PIKMIN
### This is a pikmin package.



Install pikmin using:

`
pip install pikmin
`
